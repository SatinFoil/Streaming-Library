Welcome! if your on Mac then Open the ZIP file then move it to the directory you want to install it in, If your on Windows rightclick the file then click "Extract all" then Type the location you want to install it in.

After its done, Open "index.html" to get started.
have a good day!